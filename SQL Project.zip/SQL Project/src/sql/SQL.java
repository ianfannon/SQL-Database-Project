/*
 * Created: March 20, 2017
 * Author: Ian James Fannon
 * The class SQL creates a connection to the database and closes resources
 */
package sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import javax.swing.JOptionPane;

public final class SQL {
   
    /**
     * Creates a connection to the database
     * @return 
     */
    public static Connection connectDatabase() {
        Properties properties = new Properties();
        properties.setProperty("user", ""); // Insert user name
        properties.setProperty("password", ""); // Insert password
        properties.setProperty("useSSL", "true");
        properties.setProperty("autoReconnect", "true");
        properties.setProperty("verifyServerCertificate", "false");
        Connection connection = null;
        try {
            String query = "jdbc:mysql://insert local host here / insert name of database";
            connection = DriverManager.getConnection(query, properties);
            return connection;
        } catch (SQLException ex) {
            System.err.printf("Error connecting to the database: %s", ex.getMessage());
            JOptionPane.showMessageDialog(null, "Error connecting to the database", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }
    
    /**
     * Closes resources 
     * @param statement
     * @param resultSet 
     */
    public static void closeResources(Statement statement, ResultSet resultSet) {
        try {
            if(statement != null && resultSet != null) {
                statement.close();
                resultSet.close();
            }
        } catch (SQLException ex) {
            System.err.printf("Error closing resources! %s", ex.getMessage());
        }
    }
    
    /**
     * Closes resources
     * @param preparedStatement
     * @param resultSet 
     */
    public static void closeOtherResources(PreparedStatement preparedStatement, ResultSet resultSet) {
        try {
            if(preparedStatement != null && resultSet != null) {
                preparedStatement.close();
                resultSet.close();
            }
        } catch (SQLException ex) {
            System.err.printf("Error closing resources! %s", ex.getMessage());
        }
    }
}