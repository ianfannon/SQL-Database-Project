/*
 * Created: March 20, 2017
 * Author: Ian James Fannon
 * Class is used to display, insert, edit, and delete the database values using a JTable 
 */
package sql;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.entity.StandardEntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.jdbc.JDBCCategoryDataset;

public class EmployeeInfo extends javax.swing.JFrame {

    private static final long serialVersionUID = 1L;
    private Statement statement = null;
    private ResultSet resultSet = null;
    private Connection connection = null;
    private PreparedStatement preparedStatement = null;
    private String query = "";
    private String[] values;
    private int[] intValues;
    private MessageFormat header;
    private MessageFormat footer;
    /**
     * Creates new form EmployeeInfo
     */
    public EmployeeInfo() {
        init();
    }
    /**
     * Initializes fields and calls methods
     */
    private void init() {
        initComponents();
        connection = SQL.connectDatabase();
        populateTable();
    }
    /**
     * Populates the JTable with information from the SQL database
     */
    private void populateTable() {
        try {
            query = "SELECT * FROM database123.employeeinfo"; // After FROM enter "database.table"
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();
            employeeInfoTable.setModel(DbUtils.resultSetToTableModel(resultSet));
            dataProgress.setValue(employeeInfoTable.getRowCount());
            SQL.closeOtherResources(preparedStatement, resultSet);
        } catch (SQLException ex) {
            System.err.printf("Error updating table! %s", ex.getMessage());
            JOptionPane.showMessageDialog(this, "Error loading data into table!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    /**
     * Inserts new information into the SQL database
     */
    private void insertData() {
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to insert data!", "Confirmation", JOptionPane.YES_NO_OPTION);
        if (confirm == 0) {
            try {
                statement = connection.createStatement();
                // Write query as "database.table (then enter the required column name to insert the values from the fields)
                query = "insert into database123.employeeInfo (idEmployeeInfo, name, lastname, age, username, password) values ('" + idSpinner.getValue() + "', '" + nameField.getText() + "', '"
                        + lastnameField.getText() + "', '" + ageSpinner.getValue() + "', '" + usernameField.getText() + "', '" + passwordField.getText() + "', '" + deptField.getText() + "', '" + salaryField.getText() + "')";
                statement.executeUpdate(query);
                JOptionPane.showMessageDialog(this, "Insert Complete!", "Insert", JOptionPane.INFORMATION_MESSAGE);
                populateTable();
                if (statement != null) {
                    statement.close();
                }
            } catch (SQLException ex) {            
                System.err.printf("Error inserting data! %s", ex.getMessage());
                JOptionPane.showMessageDialog(this, "Error inserting data into database!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (confirm == 1) {
            return;
        }
    }
    /**
     * Edits data on the SQL database
     */
    private void editData() {
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to edit data!", "Confirmation", JOptionPane.YES_NO_OPTION);
        if (confirm == 0) {
            try {
                values = new String[8];
                values[0] = idSpinner.getValue().toString();
                values[1] = nameField.getText();
                values[2] = lastnameField.getText();
                values[3] = ageSpinner.getValue().toString();
                values[4] = usernameField.getText();
                values[5] = passwordField.getText();
                values[6] = deptField.getText();
                values[7] = salaryField.getText();
                // After update enter "database.table" then enter the required column names to edit the values from following the field that contains the value
                query = "update database123.employeeinfo set idEmployeeInfo='" + values[0] + "', name='" + 
                        values[1] + "', lastname='" + values[2] + "', age='" + values[3] + "', username='" + 
                        values[4] + "', password='" + values[5] + "', department='" + values[6] + "', salary='" + values[7] + "' where idEmployeeInfo='" + values[0] + "'";
                preparedStatement = connection.prepareStatement(query);
                preparedStatement.execute();
                JOptionPane.showMessageDialog(this, "Database Updated!", "Update Database", JOptionPane.INFORMATION_MESSAGE);
                populateTable();
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            } catch (SQLException ex) {
                System.err.printf("Error updating data! %s", ex.getMessage());
                JOptionPane.showMessageDialog(this, "Error updating data onto database!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (confirm == 1) {
            return;
        }
    }
    /**
     * Deletes data from the SQL database
     */
    private void deleteData() {
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete data!", "Confirmation", JOptionPane.YES_NO_OPTION);
        if (confirm == 0) {
            try {
                // After from enter "database.table" then after where enter "the column name that contains the primary key" then the field to obtain the value from
                query = "delete from database123.employeeinfo where idEmployeeInfo='" + idSpinner.getValue().toString() + "'";
                preparedStatement = connection.prepareStatement(query);
                preparedStatement.execute();
                JOptionPane.showMessageDialog(this, "Data deleted from database!", "Delete", JOptionPane.INFORMATION_MESSAGE);
                populateTable();
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            } catch (SQLException ex) {
                System.err.printf("Error deleting data! %s", ex.getMessage());
                JOptionPane.showMessageDialog(this, "Error deleting data from database!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (confirm == 1) {
            return;
        }
        
    }
    /**
     * Prints the JTable
     */
    private void printData() {
        try {
            header = new MessageFormat("Report Print");
            footer = new MessageFormat("Page{0, number, integer}");
            employeeInfoTable.print(JTable.PrintMode.NORMAL, header, footer);
        } catch (PrinterException ex) {
            System.err.printf("Error printing table! %s", ex.getMessage());
            JOptionPane.showMessageDialog(this, "Error printing table!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    /**
     * Clears all the fields
     */
    private void clearFields() {
        searchField.setText("");
        idSpinner.setValue(0);
        nameField.setText("");
        lastnameField.setText("");
        ageSpinner.setValue(0);
        usernameField.setText("");
        passwordField.setText("");
        deptField.setText("");
        salaryField.setText("");
    }
    /**
     * Selects a row from the table
     * @return the table row selected
     */
    private String tableRowSelected() {
        try {
            int row = employeeInfoTable.getSelectedRow();
            String tableClick = (employeeInfoTable.getModel().getValueAt(row, 0).toString());
            // After from enter "database.table" then after where enter "the column name that contain the primary key"
            query = "select * from database123.EmployeeInfo where idEmployeeInfo='" + tableClick + "'";
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                values = new String[6];
                intValues = new int[2];
                // First get the values from the columns by enter their names
                intValues[0] = resultSet.getInt("idEmployeeInfo");
                // Then set the value to the proper field
                // And repeat this for all the columns and their cooresponding fields
                idSpinner.setValue(intValues[0]);
                values[0] = resultSet.getString("name");
                nameField.setText(values[0]);
                values[1] = resultSet.getString("lastname");
                lastnameField.setText(values[1]);
                intValues[1] = resultSet.getInt("age");
                ageSpinner.setValue(intValues[1]);
                values[2] = resultSet.getString("username");
                usernameField.setText(values[2]);
                values[3] = resultSet.getString("password");
                passwordField.setText(values[3]);
                values[4] = resultSet.getString("department");
                deptField.setText(values[4]);
                double salary = resultSet.getDouble("salary");
                salaryField.setText(Double.toString(salary));
            }
            SQL.closeOtherResources(preparedStatement, resultSet);
            return tableClick;
        } catch (SQLException ex) {
            System.err.printf("Error populating text fields! %s", ex.getMessage());
            JOptionPane.showMessageDialog(this, "Error populating text fields!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (ArrayIndexOutOfBoundsException ex) {
            System.err.printf("Error row not selected! %s", ex.getMessage());
            JOptionPane.showMessageDialog(this, "Table row must be selected!", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }
    /**
     * Opens specified files
     * @param filePath is the absolute path of the file to be opened
     */
    private void openFile(String filePath) {
        try {
            Runtime.getRuntime().exec("rundll32 url.dll, FileProtocolHandler " + filePath);
        } catch (IOException ex) {
            System.err.printf("An I/O Error has occurred! %s", ex.getMessage());
            System.exit(0);
        }
    }
    /**
     * Searches the database for specified information
     * @param columnName is the name of the column in the SQL database to search
     */
    private void searchDatabase(String columnName) {
        try {
            // After from enter "database.table" then after where you will obtain the column name from the search field via the parameter 'columnName'
            query = "select * from database123.EmployeeInfo where " + columnName + "=?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, searchField.getText());
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                values = new String[5];
                intValues = new int[2];
                // Obtain the value from the column through its name
                intValues[0] = resultSet.getInt("idemployeeinfo");
                // Then set the value to the cooresponding field
                // And repeat for all columns and fields
                idSpinner.setValue(intValues[0]);
                values[0] = resultSet.getString("name");
                nameField.setText(values[0]);
                values[1] = resultSet.getString("lastname");
                lastnameField.setText(values[1]);
                intValues[1] = resultSet.getInt("age");
                ageSpinner.setValue(intValues[1]);
                values[2] = resultSet.getString("username");
                usernameField.setText(values[2]);
                values[3] = resultSet.getString("password");
                passwordField.setText(values[3]);
                values[4] = resultSet.getString("department");
                deptField.setText(values[4]);
                double salary = resultSet.getDouble("salary");
                salaryField.setText(Double.toString(salary));
            }
        } catch (SQLException ex) {
            System.err.printf("Error search database! %s", ex.getMessage());
            JOptionPane.showMessageDialog(this, "Error searching database!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jInternalFrame1 = new javax.swing.JInternalFrame();
        jToolBar1 = new javax.swing.JToolBar();
        insertButton = new javax.swing.JButton();
        editDatabaseButton = new javax.swing.JButton();
        updateButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        printerButton = new javax.swing.JButton();
        clearButton = new javax.swing.JButton();
        barChartButton = new javax.swing.JButton();
        reportButton = new javax.swing.JButton();
        queryChartButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        employeeInfoTable = new javax.swing.JTable();
        nameField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        idSpinner = new javax.swing.JSpinner();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        ageSpinner = new javax.swing.JSpinner();
        lastnameField = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        usernameField = new javax.swing.JTextField();
        passwordField = new javax.swing.JTextField();
        dataProgress = new javax.swing.JProgressBar();
        searchField = new javax.swing.JTextField();
        searchButton = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        deptField = new javax.swing.JTextField();
        salaryField = new javax.swing.JTextField();
        jMenuBar1 = new javax.swing.JMenuBar();
        openChartMenuItem = new javax.swing.JMenu();
        insertMenuItem = new javax.swing.JMenuItem();
        updateMenuItem = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        openBarChartMenuItem = new javax.swing.JMenuItem();
        openLineChartMenuItem = new javax.swing.JMenuItem();
        openReportMenuItem = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        logoutMenuItem = new javax.swing.JMenuItem();
        exitMenuItem = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        editMenuItem = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();
        clearMenuItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jInternalFrame1.setVisible(true);

        jToolBar1.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        jToolBar1.setRollover(true);

        insertButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/database-add-icon.png"))); // NOI18N
        insertButton.setToolTipText("Insert Data");
        insertButton.setFocusable(false);
        insertButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        insertButton.setMargin(new java.awt.Insets(2, 7, 2, 7));
        insertButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        insertButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertButtonActionPerformed(evt);
            }
        });
        jToolBar1.add(insertButton);

        editDatabaseButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/data-edit-icon.png"))); // NOI18N
        editDatabaseButton.setToolTipText("Edit Database");
        editDatabaseButton.setFocusable(false);
        editDatabaseButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        editDatabaseButton.setMargin(new java.awt.Insets(2, 7, 2, 7));
        editDatabaseButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        editDatabaseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editDatabaseButtonActionPerformed(evt);
            }
        });
        jToolBar1.add(editDatabaseButton);

        updateButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Action-db-update-icon.png"))); // NOI18N
        updateButton.setToolTipText("Refresh Table");
        updateButton.setFocusable(false);
        updateButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        updateButton.setMargin(new java.awt.Insets(2, 7, 2, 7));
        updateButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        updateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateButtonActionPerformed(evt);
            }
        });
        jToolBar1.add(updateButton);

        deleteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Misc-Delete-Database-icon.png"))); // NOI18N
        deleteButton.setFocusable(false);
        deleteButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        deleteButton.setMargin(new java.awt.Insets(2, 7, 2, 7));
        deleteButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });
        jToolBar1.add(deleteButton);

        printerButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Printer-icon.png"))); // NOI18N
        printerButton.setFocusable(false);
        printerButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        printerButton.setMargin(new java.awt.Insets(2, 7, 2, 7));
        printerButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        printerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printerButtonActionPerformed(evt);
            }
        });
        jToolBar1.add(printerButton);

        clearButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Clear-icon.png"))); // NOI18N
        clearButton.setFocusable(false);
        clearButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        clearButton.setMargin(new java.awt.Insets(2, 7, 2, 7));
        clearButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });
        jToolBar1.add(clearButton);

        barChartButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bar-chart-icon.png"))); // NOI18N
        barChartButton.setToolTipText("Bar Chart of Selected Employee");
        barChartButton.setFocusable(false);
        barChartButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        barChartButton.setMargin(new java.awt.Insets(2, 7, 2, 7));
        barChartButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        barChartButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                barChartButtonActionPerformed(evt);
            }
        });
        jToolBar1.add(barChartButton);

        reportButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/report-edit-icon.png"))); // NOI18N
        reportButton.setToolTipText("Create Report");
        reportButton.setFocusable(false);
        reportButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        reportButton.setMargin(new java.awt.Insets(2, 7, 2, 7));
        reportButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        reportButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportButtonActionPerformed(evt);
            }
        });
        jToolBar1.add(reportButton);

        queryChartButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/chart-bullseye-icon.png"))); // NOI18N
        queryChartButton.setToolTipText("Query Chart");
        queryChartButton.setFocusable(false);
        queryChartButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        queryChartButton.setMargin(new java.awt.Insets(2, 7, 2, 7));
        queryChartButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        queryChartButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                queryChartButtonActionPerformed(evt);
            }
        });
        jToolBar1.add(queryChartButton);

        jScrollPane1.setToolTipText("Employee Information from Database");
        jScrollPane1.setViewportBorder(javax.swing.BorderFactory.createEtchedBorder());

        employeeInfoTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        employeeInfoTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                employeeInfoTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(employeeInfoTable);

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("ID:");

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Name:");

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Username:");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Last Name:");

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Age:");

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Password:");

        dataProgress.setStringPainted(true);

        searchButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Search-icon (1).png"))); // NOI18N
        searchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchButtonActionPerformed(evt);
            }
        });

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/database-icon.png"))); // NOI18N

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Department:");

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Salary:");

        openChartMenuItem.setText("File");
        openChartMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openChartMenuItemActionPerformed(evt);
            }
        });

        insertMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/database-add-icon.png"))); // NOI18N
        insertMenuItem.setText("Insert Data");
        insertMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertMenuItemActionPerformed(evt);
            }
        });
        openChartMenuItem.add(insertMenuItem);

        updateMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Action-db-update-icon.png"))); // NOI18N
        updateMenuItem.setText("Refresh Data");
        updateMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateMenuItemActionPerformed(evt);
            }
        });
        openChartMenuItem.add(updateMenuItem);

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Open-icon.png"))); // NOI18N
        jMenu1.setText("Open Chart");

        openBarChartMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bar-chart-icon.png"))); // NOI18N
        openBarChartMenuItem.setText("Open Bar Chart");
        openBarChartMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openBarChartMenuItemActionPerformed(evt);
            }
        });
        jMenu1.add(openBarChartMenuItem);

        openLineChartMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/chart-bullseye-icon.png"))); // NOI18N
        openLineChartMenuItem.setText("Open Line Chart");
        openLineChartMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openLineChartMenuItemActionPerformed(evt);
            }
        });
        jMenu1.add(openLineChartMenuItem);

        openChartMenuItem.add(jMenu1);

        openReportMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Open-icon.png"))); // NOI18N
        openReportMenuItem.setText("Open Report");
        openReportMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openReportMenuItemActionPerformed(evt);
            }
        });
        openChartMenuItem.add(openReportMenuItem);

        jMenuItem2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Printer-icon.png"))); // NOI18N
        jMenuItem2.setText("Print Table");
        openChartMenuItem.add(jMenuItem2);

        logoutMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Apps-Dialog-Logout-icon.png"))); // NOI18N
        logoutMenuItem.setText("Logout");
        logoutMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutMenuItemActionPerformed(evt);
            }
        });
        openChartMenuItem.add(logoutMenuItem);

        exitMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Button-Close-icon.png"))); // NOI18N
        exitMenuItem.setText("Exit");
        exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitMenuItemActionPerformed(evt);
            }
        });
        openChartMenuItem.add(exitMenuItem);

        jMenuBar1.add(openChartMenuItem);

        jMenu2.setText("Edit");

        editMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/data-edit-icon.png"))); // NOI18N
        editMenuItem.setText("Edit Data");
        editMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editMenuItemActionPerformed(evt);
            }
        });
        jMenu2.add(editMenuItem);

        jMenuItem1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Misc-Delete-Database-icon.png"))); // NOI18N
        jMenuItem1.setText("Delete Data");
        jMenu2.add(jMenuItem1);

        clearMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Clear-icon.png"))); // NOI18N
        clearMenuItem.setText("Clear Fields");
        clearMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearMenuItemActionPerformed(evt);
            }
        });
        jMenu2.add(clearMenuItem);

        jMenuBar1.add(jMenu2);

        jInternalFrame1.setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout jInternalFrame1Layout = new javax.swing.GroupLayout(jInternalFrame1.getContentPane());
        jInternalFrame1.getContentPane().setLayout(jInternalFrame1Layout);
        jInternalFrame1Layout.setHorizontalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jToolBar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jInternalFrame1Layout.createSequentialGroup()
                        .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(nameField, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ageSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lastnameField, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(usernameField, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(idSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                                .addComponent(dataProgress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(searchButton, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 690, Short.MAX_VALUE)))
                    .addGroup(jInternalFrame1Layout.createSequentialGroup()
                        .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(salaryField, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deptField, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jInternalFrame1Layout.setVerticalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jInternalFrame1Layout.createSequentialGroup()
                        .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(idSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(22, 22, 22)
                        .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(nameField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lastnameField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(25, 25, 25)
                                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(ageSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(usernameField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jInternalFrame1Layout.createSequentialGroup()
                        .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(dataProgress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(searchField)
                            .addComponent(searchButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(deptField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(salaryField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jInternalFrame1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jInternalFrame1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void insertButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertButtonActionPerformed
        insertData();
    }//GEN-LAST:event_insertButtonActionPerformed
    
    /**
     * Exits the window and closes the connection to the SQL database
     * @param evt 
     */
    private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException ex) {
            System.err.printf("Error closing connection! %s", ex.getMessage());
        }
        System.exit(0);
    }//GEN-LAST:event_exitMenuItemActionPerformed

    // Edits data in a selected row
    private void editDatabaseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editDatabaseButtonActionPerformed
        editData();
    }//GEN-LAST:event_editDatabaseButtonActionPerformed

    // Selects a row by using the mouse
    private void employeeInfoTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_employeeInfoTableMouseClicked
        tableRowSelected();
    }//GEN-LAST:event_employeeInfoTableMouseClicked

    // Inserts data into a new row
    private void insertMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertMenuItemActionPerformed
        insertData();
    }//GEN-LAST:event_insertMenuItemActionPerformed

    // Edits data in a selected row
    private void editMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editMenuItemActionPerformed
        editData();
    }//GEN-LAST:event_editMenuItemActionPerformed

    // Enter the values from the database into the JTable
    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        populateTable();
    }//GEN-LAST:event_updateButtonActionPerformed

    // Enter the values from the database into the JTable
    private void updateMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateMenuItemActionPerformed
        populateTable();
    }//GEN-LAST:event_updateMenuItemActionPerformed

    /**
     * Logs out of the account and closes the connection to the SQL database
     * @param evt 
     */
    private void logoutMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutMenuItemActionPerformed
        JOptionPane.showMessageDialog(this, "Login Successful!", "Login", JOptionPane.INFORMATION_MESSAGE);
        Login login = new Login();
        login.setVisible(true);
        login.setResizable(false);
        login.setLocationRelativeTo(null);
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException ex) {
            System.err.printf("Error logging out! %s", ex.getMessage());
        }
        dispose();
    }//GEN-LAST:event_logoutMenuItemActionPerformed

    // Deletes a row of values
    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        deleteData();
    }//GEN-LAST:event_deleteButtonActionPerformed

    /**
     * Searches the database based on the columns by entering their names
     * @param evt 
     */
    private void searchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchButtonActionPerformed
        searchDatabase("name");
        searchDatabase("lastname");
        searchDatabase("idemployeeinfo");
    }//GEN-LAST:event_searchButtonActionPerformed
    // Prints the table
    private void printerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printerButtonActionPerformed
        printData();
    }//GEN-LAST:event_printerButtonActionPerformed
    // Prints the table
    private void openChartMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openChartMenuItemActionPerformed
        printData();
    }//GEN-LAST:event_openChartMenuItemActionPerformed
    // Clears the fields
    private void clearMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearMenuItemActionPerformed
        clearFields();
    }//GEN-LAST:event_clearMenuItemActionPerformed
    // Clears the fields
    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        clearFields();
    }//GEN-LAST:event_clearButtonActionPerformed
    // Creates the bar chart with data from the SQL database and saves it to file
    private void barChartButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_barChartButtonActionPerformed
        try {
            // Obtains information from the SQL database to display in the chart
            query = "select lastname, salary from database123.employeeinfo";
            JDBCCategoryDataset dataset = new JDBCCategoryDataset(SQL.connectDatabase(), query);
            // Creats the bar chart (title, xAxis title, yAxis title, connection to database, chart display)
            JFreeChart chart = ChartFactory.createBarChart3D("Employee Salary's", "lastname", "salary", dataset, PlotOrientation.VERTICAL, false, true, false);
            chart.setBackgroundPaint(Color.YELLOW);
            chart.getTitle().setPaint(Color.RED);
            CategoryPlot plot = chart.getCategoryPlot();
            plot.setRangeGridlinePaint(Color.BLUE);
            // Displays the chart and set the title
            ChartFrame frame = new ChartFrame("Employee Salary Bar Chart", chart);
            frame.setVisible(true);
            frame.setSize(new Dimension(450, 350));
            // Save the chart to an image file
            final ChartRenderingInfo renderingInfo = new ChartRenderingInfo(new StandardEntityCollection());
            final File file = new File("employeeInfoChart.png");
            ChartUtilities.saveChartAsPNG(file, chart, 600, 400, renderingInfo);
            JOptionPane.showMessageDialog(this, "Bar Chart file created!", "Bar Chart File", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException ex) {
            System.err.printf("Error row not selected! %s", ex.getMessage());
            JOptionPane.showMessageDialog(this, "You must select a table row!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (IOException ex) {
            System.err.printf("An I/O error occurred! %s", ex.getMessage());
            System.exit(0);
        } catch (SQLException ex) {
            System.err.printf("Error creating bar chart! %s", ex.getMessage());
            JOptionPane.showMessageDialog(this, "Error creating bar chart!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_barChartButtonActionPerformed
    
    // Creates and saves a report containing information from the SQL database
    private void reportButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reportButtonActionPerformed
        Document document = new Document();
        PdfPTable table = new PdfPTable(8);
        try {
            if (tableRowSelected() != null) {
                PdfWriter.getInstance(document, new FileOutputStream("employeeReport.pdf")); // Creates the pdf document
                document.open(); // Opens the pdf document
                Image image = Image.getInstance("enter the absolute file path of the image to be added to the pdf report"); // the file path of the document to store the image
                document.add(new Paragraph("Employee Information Database")); // Title
                document.add(image); // Adds the image to the document
                document.add(new Paragraph("Report", FontFactory.getFont(FontFactory.TIMES_ROMAN, 14, Font.BOLD, BaseColor.RED)));
                document.add(new Paragraph(new Date().toString()));
                document.add(new Paragraph("---------------------------------------------------------------------------------------------------------------------------------"));
                // Create the columns to hold the employee information in the table based on the columns names from the database table
                PdfPCell cell = new PdfPCell(new Paragraph("Employee Information", FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, Font.BOLD)));
                cell.setColspan(8);
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell.setBackgroundColor(BaseColor.GREEN);
                table.addCell(cell);
                
                PdfPCell cell1 = new PdfPCell(new Paragraph("ID", FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, Font.BOLD)));
                cell1.setColspan(1);
                cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell1.setBackgroundColor(BaseColor.YELLOW);
                table.addCell(cell1);

                PdfPCell cell2 = new PdfPCell(new Paragraph("Name", FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, Font.BOLD)));
                cell2.setColspan(1);
                cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell2.setBackgroundColor(BaseColor.YELLOW);
                table.addCell(cell2);

                PdfPCell cell3 = new PdfPCell(new Paragraph("Last Name", FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, Font.BOLD)));
                cell3.setColspan(1);
                cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell3.setBackgroundColor(BaseColor.YELLOW);
                table.addCell(cell3);

                PdfPCell cell4 = new PdfPCell(new Paragraph("Age", FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, Font.BOLD)));
                cell4.setColspan(1);
                cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell4.setBackgroundColor(BaseColor.YELLOW);
                table.addCell(cell4);

                PdfPCell cell5 = new PdfPCell(new Paragraph("Username", FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, Font.BOLD)));
                cell5.setColspan(1);
                cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell5.setBackgroundColor(BaseColor.YELLOW);
                table.addCell(cell5);

                PdfPCell cell6 = new PdfPCell(new Paragraph("Password", FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, Font.BOLD)));
                cell6.setColspan(1);
                cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell6.setBackgroundColor(BaseColor.YELLOW);
                table.addCell(cell6);

                PdfPCell cell7 = new PdfPCell(new Paragraph("Department", FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, Font.BOLD)));
                cell7.setColspan(1);
                cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell7.setBackgroundColor(BaseColor.YELLOW);
                table.addCell(cell7);

                PdfPCell cell8 = new PdfPCell(new Paragraph("Salary", FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, Font.BOLD)));
                cell8.setColspan(1);
                cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell8.setBackgroundColor(BaseColor.YELLOW);
                table.addCell(cell8);
                // Store the text field values in a string array
                values = new String[8];
                values[0] = idSpinner.getValue().toString();
                values[1] = nameField.getText();
                values[2] = lastnameField.getText();
                values[3] = ageSpinner.getValue().toString();
                values[4] = usernameField.getText();
                values[5] = passwordField.getText();
                values[6] = deptField.getText();
                values[7] = salaryField.getText();
                // Add text field values to pdf file to fill the cells of the table
                table.addCell(values[0]);
                table.addCell(values[1]);
                table.addCell(values[2]);
                table.addCell(values[3]);
                table.addCell(values[4]);
                table.addCell(values[5]);
                table.addCell(values[6]);
                table.addCell(values[7]);
                // 20 is the maximum number of items
                com.itextpdf.text.List list = new com.itextpdf.text.List(true, 20);
                list.add("First Item");
                list.add("Second Item");
                list.add("Third Item");
                list.add("Fourth Item");
                // Stores the bar chart picture in the pdf file
                com.itextpdf.text.Image chartImage = com.itextpdf.text.Image.getInstance("employeeInfoSalaryChart.png");
                chartImage.scaleAbsolute(350, 250);
                // Add elements to document
                document.add(table);
                document.add(list);
                document.add(chartImage);
            } else {
                JOptionPane.showMessageDialog(this, "Table row must be selected!", "Report", JOptionPane.ERROR_MESSAGE);
            }
            JOptionPane.showMessageDialog(this, "Report Created", "Report", JOptionPane.INFORMATION_MESSAGE);
        } catch (DocumentException ex) {
            System.err.printf("Error with document! %s", ex.getMessage());
            JOptionPane.showMessageDialog(this, "Pdf File must be closed to save!", "Report", JOptionPane.ERROR_MESSAGE);
        } catch (FileNotFoundException ex) {
            System.err.printf("Error with document! %s", ex.getMessage());
        } catch (MalformedURLException ex) {
            System.err.printf("Error locating image! %s", ex.getMessage());
        } catch (IOException ex) {
            System.err.printf("An I/O Error has occurred! %s", ex.getMessage());
            System.exit(0);
        } finally {
            document.close();
        }
    }//GEN-LAST:event_reportButtonActionPerformed
    // Opens the created pdf report contain information about the SQL database
    private void openReportMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openReportMenuItemActionPerformed
        openFile("enter the absolute file path where the following pdf is stored \\employeeReport.pdf");
    }//GEN-LAST:event_openReportMenuItemActionPerformed
    // Opens the created bar chart displaying
    private void openBarChartMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openBarChartMenuItemActionPerformed
        openFile("enter the absolute file path where the created chart is stored \\employeeInfoChart.png");
    }//GEN-LAST:event_openBarChartMenuItemActionPerformed
    // Method creates a chart with SQL database values and displays them in a line chart
    private void queryChartButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_queryChartButtonActionPerformed
        try {
            // After select enter "column name" that you want to obtain the values then after from enter "database.table"
            query = "select lastname, salary from database123.employeeinfo";
            JDBCCategoryDataset dataset = new JDBCCategoryDataset(SQL.connectDatabase(), query);
            // The parameters are the title, the vertical values title, the horizontal values title
            JFreeChart chart = ChartFactory.createLineChart3D("Employee Information Database", "salary", "lastname", dataset, PlotOrientation.VERTICAL, false, true, true);
            // Create the frame that holds the chart
            ChartFrame frame = new ChartFrame("Employee Information Database Chart", chart);
            frame.setVisible(true);
            frame.setSize(new Dimension(400, 650));
            
            final ChartRenderingInfo renderingInfo = new ChartRenderingInfo(new StandardEntityCollection());
            // The file to be created that contain the chart
            final File file = new File("employeeInfoSalaryChart.png");
            ChartUtilities.saveChartAsPNG(file, chart, 600, 400, renderingInfo);
            JOptionPane.showMessageDialog(this, "Bar Chart file created!", "Bar Chart File", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            System.err.printf("Error creating chart! %s", ex.getMessage());
            JOptionPane.showMessageDialog(this, "Error creating chart!", "Database Chart", JOptionPane.ERROR_MESSAGE);
        } catch (IOException ex) {
            System.err.printf("An I/O Error has occurred! %s", ex.getMessage());
            System.exit(0);
        }
    }//GEN-LAST:event_queryChartButtonActionPerformed
    // Opens the created line chart
    private void openLineChartMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openLineChartMenuItemActionPerformed
        openFile("C:\\Users\\Ian James Fannon\\Documents\\NetBeansProjects\\SQL Project\\employeeInfoSalaryChart.png");
    }//GEN-LAST:event_openLineChartMenuItemActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmployeeInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            EmployeeInfo employeeInfo = new EmployeeInfo();
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSpinner ageSpinner;
    private javax.swing.JButton barChartButton;
    private javax.swing.JButton clearButton;
    private javax.swing.JMenuItem clearMenuItem;
    private javax.swing.JProgressBar dataProgress;
    private javax.swing.JButton deleteButton;
    private javax.swing.JTextField deptField;
    private javax.swing.JButton editDatabaseButton;
    private javax.swing.JMenuItem editMenuItem;
    private javax.swing.JTable employeeInfoTable;
    private javax.swing.JMenuItem exitMenuItem;
    private javax.swing.JSpinner idSpinner;
    private javax.swing.JButton insertButton;
    private javax.swing.JMenuItem insertMenuItem;
    private javax.swing.JInternalFrame jInternalFrame1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JTextField lastnameField;
    private javax.swing.JMenuItem logoutMenuItem;
    private javax.swing.JTextField nameField;
    private javax.swing.JMenuItem openBarChartMenuItem;
    private javax.swing.JMenu openChartMenuItem;
    private javax.swing.JMenuItem openLineChartMenuItem;
    private javax.swing.JMenuItem openReportMenuItem;
    private javax.swing.JTextField passwordField;
    private javax.swing.JButton printerButton;
    private javax.swing.JButton queryChartButton;
    private javax.swing.JButton reportButton;
    private javax.swing.JTextField salaryField;
    private javax.swing.JButton searchButton;
    private javax.swing.JTextField searchField;
    private javax.swing.JButton updateButton;
    private javax.swing.JMenuItem updateMenuItem;
    private javax.swing.JTextField usernameField;
    // End of variables declaration//GEN-END:variables
}
